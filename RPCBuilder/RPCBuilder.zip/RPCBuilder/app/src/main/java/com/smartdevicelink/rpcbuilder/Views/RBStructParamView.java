package com.smartdevicelink.rpcbuilder.Views;

import android.content.Context;

public class RBStructParamView extends RBParamView {
	public RBStructParamView(Context context) {
		super(context);
	}
}
