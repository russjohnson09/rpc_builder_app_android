package com.smartdevicelink.rpcbuilder.DataModels;

import org.xml.sax.Attributes;

/**
 * Created by amulle19 on 10/25/16.
 */

public class RBElement extends RBBaseObject {
//    public RBElement(String name, String description) {
//        super(name, description);
//    }

    public RBElement(Attributes attributes) {
        super(attributes);
    }
}
