package com.smartdevicelink.rpcbuilder.SmartDeviceLink;

public class SdlRouterService extends  com.smartdevicelink.transport.SdlRouterService {
//Nothing to do here
}
